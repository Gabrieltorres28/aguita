"use client"

import { useMemo, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ArrowLeft, Trash2, Phone, MapPin } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import type { Cliente, Movimiento } from "@/lib/types"
import { formatARS, formatFechaHora } from "@/lib/storage"
import { Label } from "@/components/ui/label"

type Props = {
  clientes: Cliente[]
  movimientos: Movimiento[]
  clienteSeleccionadoId: string | null
  onSeleccionarCliente: (id: string) => void
  onVolver: () => void
  onEliminarMovimiento: (id: string) => void
  onIrRegistrar: (clienteId: string) => void
}

const tipoLabel: Record<Movimiento["tipo"], string> = {
  entrega: "Entrega",
  retiro: "Retiro de envases",
  pago: "Pago recibido",
  ajuste: "Ajuste",
}

const tipoColor: Record<Movimiento["tipo"], string> = {
  entrega: "bg-primary/10 text-primary",
  retiro: "bg-amber-100 text-amber-800",
  pago: "bg-emerald-100 text-emerald-700",
  ajuste: "bg-muted text-muted-foreground",
}

export function CuentaCorriente({
  clientes,
  movimientos,
  clienteSeleccionadoId,
  onSeleccionarCliente,
  onVolver,
  onEliminarMovimiento,
  onIrRegistrar,
}: Props) {
  const [eliminandoId, setEliminandoId] = useState<string | null>(null)

  const cliente = useMemo(
    () => clientes.find((c) => c.id === clienteSeleccionadoId) ?? null,
    [clientes, clienteSeleccionadoId],
  )

  const movs = useMemo(
    () =>
      movimientos
        .filter((m) => m.clienteId === clienteSeleccionadoId)
        .sort((a, b) => (a.fecha < b.fecha ? 1 : -1)),
    [movimientos, clienteSeleccionadoId],
  )

  if (!cliente) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Cuenta corriente</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <Label>Seleccioná un cliente</Label>
          <Select
            value={clienteSeleccionadoId ?? ""}
            onValueChange={onSeleccionarCliente}
          >
            <SelectTrigger className="h-11">
              <SelectValue placeholder="Elegir cliente..." />
            </SelectTrigger>
            <SelectContent>
              {clientes.length === 0 ? (
                <div className="px-2 py-2 text-sm text-muted-foreground">
                  No hay clientes cargados.
                </div>
              ) : (
                clientes.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.nombre}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="size-10 shrink-0"
          onClick={onVolver}
          aria-label="Volver"
        >
          <ArrowLeft className="size-5" />
        </Button>
        <h2 className="text-lg font-semibold leading-tight">{cliente.nombre}</h2>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-3 p-4">
          <div className="flex flex-col gap-1 text-sm text-muted-foreground">
            {cliente.telefono && (
              <span className="flex items-center gap-2">
                <Phone className="size-3.5" />
                {cliente.telefono}
              </span>
            )}
            {cliente.direccion && (
              <span className="flex items-center gap-2">
                <MapPin className="size-3.5" />
                {cliente.direccion}
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-md border border-border bg-muted/40 px-3 py-3">
              <p className="text-xs text-muted-foreground">Saldo</p>
              <p
                className={`text-lg font-bold ${
                  cliente.saldo < 0
                    ? "text-destructive"
                    : cliente.saldo > 0
                      ? "text-emerald-600"
                      : "text-foreground"
                }`}
              >
                {formatARS(cliente.saldo)}
              </p>
              <p className="text-[11px] text-muted-foreground">
                {cliente.saldo < 0
                  ? "Debe"
                  : cliente.saldo > 0
                    ? "A favor"
                    : "Al día"}
              </p>
            </div>
            <div className="rounded-md border border-border bg-muted/40 px-3 py-3">
              <p className="text-xs text-muted-foreground">Envases en calle</p>
              <p className="text-lg font-bold">{cliente.envasesComodato}</p>
              <p className="text-[11px] text-muted-foreground">
                en comodato
              </p>
            </div>
          </div>

          <Button
            size="lg"
            className="h-11 w-full"
            onClick={() => onIrRegistrar(cliente.id)}
          >
            Registrar movimiento para este cliente
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">
            Historial ({movs.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-2 p-4 pt-0">
          {movs.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Sin movimientos para este cliente.
            </p>
          ) : (
            movs.map((m) => (
              <div
                key={m.id}
                className="flex flex-col gap-2 rounded-md border border-border bg-card p-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex flex-col gap-1">
                    <span
                      className={`inline-flex w-fit items-center rounded-full px-2 py-0.5 text-[11px] font-medium ${tipoColor[m.tipo]}`}
                    >
                      {tipoLabel[m.tipo]}
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      {formatFechaHora(m.fecha)}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8 text-destructive hover:text-destructive"
                    onClick={() => setEliminandoId(m.id)}
                    aria-label="Eliminar movimiento"
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
                  {m.bidonesEntregados > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Bidones</span>
                      <span className="font-medium">
                        {m.bidonesEntregados}
                      </span>
                    </div>
                  )}
                  {m.envasesRetirados > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">
                        Envases ret.
                      </span>
                      <span className="font-medium">{m.envasesRetirados}</span>
                    </div>
                  )}
                  {m.total > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total</span>
                      <span className="font-medium">
                        {formatARS(m.total)}
                      </span>
                    </div>
                  )}
                  {m.pagoRecibido !== 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Pago</span>
                      <span className="font-medium text-emerald-700">
                        {formatARS(m.pagoRecibido)}
                      </span>
                    </div>
                  )}
                  <div className="col-span-2 flex justify-between border-t border-border pt-1">
                    <span className="text-muted-foreground">
                      Saldo resultante
                    </span>
                    <span
                      className={`font-semibold ${
                        m.saldoResultante < 0
                          ? "text-destructive"
                          : m.saldoResultante > 0
                            ? "text-emerald-600"
                            : ""
                      }`}
                    >
                      {formatARS(m.saldoResultante)}
                    </span>
                  </div>
                </div>

                {m.observacion && (
                  <p className="border-t border-border pt-2 text-xs text-muted-foreground">
                    {m.observacion}
                  </p>
                )}
              </div>
            ))
          )}
        </CardContent>
      </Card>

      <AlertDialog
        open={eliminandoId !== null}
        onOpenChange={(open) => !open && setEliminandoId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar movimiento?</AlertDialogTitle>
            <AlertDialogDescription>
              El saldo y los envases en comodato del cliente se ajustarán
              automáticamente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (eliminandoId) onEliminarMovimiento(eliminandoId)
                setEliminandoId(null)
              }}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
